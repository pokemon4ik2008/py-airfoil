#ifndef __INIT_H__
#define __INIT_H__

#include "global.h"

void build_tool_bar ();

void build_numeric_dialog_boxes ();

void make_color_pallete();
void make_gray_pallete();

#endif
