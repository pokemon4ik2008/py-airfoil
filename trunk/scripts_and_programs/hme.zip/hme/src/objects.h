#ifndef __objects_H__
#define __objects_H__

#include "global.h"
void do_load_object(char * FileName, terrain_object *this_current_object);
bool load_bmp_object(char * FileName, terrain_object *this_current_object);
#endif
