#ifndef __SETTINGS_H__
#define __SETTINGS_H__

#include "global.h"

//load the settings, at startup
void load_settings ();

void save_settings ();

#endif
