#ifndef __ISOMETRIC_H__
#define __ISOMETRIC_H__

#include "global.h"


#endif
